//
//  ARDAppClient.h
//  ARDAppClient
//
//  Created by MihirVyas on 19/2/20.
//  Copyright (c) 2019 AcentriaTech. All rights reserved.
//
#import <UIKit/UIKit.h>

//! Project version number for ARDAppClient.
FOUNDATION_EXPORT double ARDAppClientVersionNumber;

//! Project version string for ARDAppClient.
FOUNDATION_EXPORT const unsigned char ARDAppClientVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ARDAppClient/PublicHeader.h>


